# COMP 3612, Fall 2021
### Assessment for Lab #5 on Chapter 10

I will mark Chapter 10, Project 1 in textbook, pages 540-541. I have also provided a PDF of those pages.

I have provided the starting files here.


  
